import { Page, Locator, expect } from '@playwright/test';

/**
 * Page Object Model for Dream Portal Home Page (index.html)
 */
export class HomePage {
  readonly page: Page;

  // Locators
  readonly loadingOverlay: Locator;
  readonly loadingSpinner: Locator;
  readonly mainContent: Locator;
  readonly portalTitle: Locator;
  readonly myDreamsButton: Locator;
  readonly dreamCountStat: Locator;
  readonly dayCountStat: Locator;

  constructor(page: Page) {
    this.page = page;
    this.loadingOverlay = page.locator('#loading-screen, .loading-screen, [class*="loading"]').first();
    this.loadingSpinner = page.locator('.spinner, [class*="spinner"], .loading-animation').first();
    this.mainContent = page.locator('#main-content, .main-content, main').first();
    this.portalTitle = page.locator('h1').filter({ hasText: /Dream Portal/i }).first();
    this.myDreamsButton = page.locator('a, button').filter({ hasText: /My Dreams/i }).first();
    this.dreamCountStat = page.locator('text=10 Dreams');
    this.dayCountStat = page.locator('text=7 Days');
  }

  /**
   * Navigate to the home page
   */
  async goto(): Promise<void> {
    await this.page.goto('/');
    await this.page.waitForLoadState('domcontentloaded');
  }

  /**
   * Wait for the loading animation to appear
   */
  async waitForLoadingAnimationToAppear(): Promise<boolean> {
    try {
      // The loading screen should be visible initially
      const loadingVisible = await this.page.locator(
        '#loading-screen, .loading-screen, [id*="loading"], [class*="loading"]'
      ).first().isVisible();
      return loadingVisible;
    } catch {
      return false;
    }
  }

  /**
   * Wait for the loading animation to disappear (up to 6 seconds)
   */
  async waitForLoadingAnimationToDisappear(): Promise<void> {
    // Wait for any loading element to disappear
    await this.page.waitForFunction(() => {
      const loadingElements = document.querySelectorAll(
        '#loading-screen, .loading-screen, [id*="loading"], [class*="loading"]'
      );
      for (const el of loadingElements) {
        const style = window.getComputedStyle(el);
        if (style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0') {
          return false;
        }
      }
      return true;
    }, { timeout: 8000 });
  }

  /**
   * Check if main content is visible
   */
  async isMainContentVisible(): Promise<boolean> {
    try {
      // Check for portal content - title or main content area
      const titleVisible = await this.page.locator('h1, h2').filter({ hasText: /Dream Portal/i }).first().isVisible();
      return titleVisible;
    } catch {
      return false;
    }
  }

  /**
   * Check if "My Dreams" button is visible
   */
  async isMyDreamButtonVisible(): Promise<boolean> {
    try {
      return await this.myDreamsButton.isVisible();
    } catch {
      return false;
    }
  }

  /**
   * Click "My Dreams" and capture newly opened tabs
   */
  async clickMyDreamsAndGetNewPages(): Promise<Page[]> {
    const context = this.page.context();
    const existingPages = context.pages();

    await this.myDreamsButton.click();

    // Wait for new tabs to open (up to 5 seconds)
    await this.page.waitForTimeout(3000);

    const allPages = context.pages();
    const newPages = allPages.filter(p => !existingPages.includes(p));

    // Wait for new pages to load
    for (const newPage of newPages) {
      await newPage.waitForLoadState('domcontentloaded');
    }

    return newPages;
  }

  /**
   * Get the page URL list after clicking My Dreams
   */
  async getNewTabUrls(): Promise<string[]> {
    const newPages = await this.clickMyDreamsAndGetNewPages();
    return newPages.map(p => p.url());
  }
}
