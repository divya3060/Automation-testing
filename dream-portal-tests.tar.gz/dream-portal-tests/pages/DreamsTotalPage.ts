import { Page, Locator } from '@playwright/test';

export interface DreamStats {
  goodDreams: number;
  badDreams: number;
  totalDreams: number;
  recurringDreams: number;
}

/**
 * Page Object Model for Dreams Summary/Total Page (dreams-total.html)
 */
export class DreamsTotalPage {
  readonly page: Page;

  readonly pageTitle: Locator;
  readonly statsContainer: Locator;

  constructor(page: Page) {
    this.page = page;
    this.pageTitle = page.locator('h1, h2, h3').first();
    this.statsContainer = page.locator('body');
  }

  /**
   * Navigate directly to dreams-total.html
   */
  async goto(): Promise<void> {
    await this.page.goto('/dreams-total.html');
    await this.page.waitForLoadState('domcontentloaded');
  }

  /**
   * Generic helper to extract a numeric stat from text on the page
   */
  private async extractStatByLabel(labelPattern: RegExp): Promise<number> {
    // Try multiple selector strategies
    const strategies = [
      // Look for a container with the label text nearby a number
      async () => {
        const elements = await this.page.locator('*').allTextContents();
        for (const text of elements) {
          if (labelPattern.test(text)) {
            const match = text.match(/(\d+)/);
            if (match) return parseInt(match[1]);
          }
        }
        return null;
      },
      // Look for elements with just numbers near the label
      async () => {
        const locator = this.page.locator(`text=${labelPattern.source}`).first();
        const parent = locator.locator('..');
        const numText = await parent.textContent();
        const match = numText?.match(/(\d+)/);
        return match ? parseInt(match[1]) : null;
      },
    ];

    for (const strategy of strategies) {
      const result = await strategy();
      if (result !== null) return result;
    }

    throw new Error(`Could not extract stat for pattern: ${labelPattern}`);
  }

  /**
   * Extract all dream stats from the summary page
   */
  async getDreamStats(): Promise<DreamStats> {
    await this.page.waitForLoadState('networkidle');

    const pageText = await this.page.locator('body').textContent() || '';

    const extractNumber = (pattern: RegExp): number => {
      const match = pageText.match(pattern);
      return match ? parseInt(match[1]) : -1;
    };

    // Try multiple patterns to match the stats displayed
    const goodDreams =
      extractNumber(/Good\s*Dreams?\s*[:\-]?\s*(\d+)/i) ||
      extractNumber(/(\d+)\s*Good\s*Dreams?/i);

    const badDreams =
      extractNumber(/Bad\s*Dreams?\s*[:\-]?\s*(\d+)/i) ||
      extractNumber(/(\d+)\s*Bad\s*Dreams?/i);

    const totalDreams =
      extractNumber(/Total\s*Dreams?\s*[:\-]?\s*(\d+)/i) ||
      extractNumber(/(\d+)\s*Total\s*Dreams?/i);

    const recurringDreams =
      extractNumber(/Recurring\s*Dreams?\s*[:\-]?\s*(\d+)/i) ||
      extractNumber(/(\d+)\s*Recurring\s*Dreams?/i);

    return {
      goodDreams: goodDreams ?? -1,
      badDreams: badDreams ?? -1,
      totalDreams: totalDreams ?? -1,
      recurringDreams: recurringDreams ?? -1,
    };
  }

  /**
   * Get the raw page text for debugging
   */
  async getPageText(): Promise<string> {
    return (await this.page.locator('body').textContent()) || '';
  }

  /**
   * Check if specific stat value is present on the page
   */
  async isStatPresent(value: number, label: string): Promise<boolean> {
    const pageText = await this.getPageText();
    const pattern = new RegExp(`${label}[^\\d]*${value}|${value}[^\\d]*${label}`, 'i');
    return pattern.test(pageText);
  }
}
