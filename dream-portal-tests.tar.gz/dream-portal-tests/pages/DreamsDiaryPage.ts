import { Page, Locator } from '@playwright/test';

export interface DreamEntry {
  name: string;
  daysAgo: string;
  dreamType: string;
}

/**
 * Page Object Model for Dream Diary Page (dreams-diary.html)
 */
export class DreamsDiaryPage {
  readonly page: Page;

  readonly pageTitle: Locator;
  readonly dreamTable: Locator;
  readonly tableRows: Locator;
  readonly tableBody: Locator;

  constructor(page: Page) {
    this.page = page;
    this.pageTitle = page.locator('h1, h2, h3').first();
    this.dreamTable = page.locator('table').first();
    this.tableBody = page.locator('table tbody').first();
    this.tableRows = page.locator('table tbody tr');
  }

  /**
   * Navigate directly to dreams-diary.html
   */
  async goto(): Promise<void> {
    await this.page.goto('/dreams-diary.html');
    await this.page.waitForLoadState('domcontentloaded');
    await this.page.waitForSelector('table', { timeout: 10000 });
  }

  /**
   * Get total count of dream entries (table rows)
   */
  async getDreamCount(): Promise<number> {
    await this.page.waitForSelector('table tbody tr', { timeout: 10000 });
    return await this.tableRows.count();
  }

  /**
   * Get all dream entries as structured objects
   */
  async getAllDreamEntries(): Promise<DreamEntry[]> {
    await this.page.waitForSelector('table tbody tr', { timeout: 10000 });
    const rows = await this.tableRows.all();
    const entries: DreamEntry[] = [];

    for (const row of rows) {
      const cells = await row.locator('td').all();
      if (cells.length >= 3) {
        const name = (await cells[0].textContent() || '').trim();
        const daysAgo = (await cells[1].textContent() || '').trim();
        const dreamType = (await cells[2].textContent() || '').trim();
        entries.push({ name, daysAgo, dreamType });
      }
    }

    return entries;
  }

  /**
   * Get all dream types from the table
   */
  async getAllDreamTypes(): Promise<string[]> {
    const entries = await this.getAllDreamEntries();
    return entries.map(e => e.dreamType);
  }

  /**
   * Validate that all dream types are either "Good" or "Bad"
   */
  async validateDreamTypes(): Promise<{ valid: boolean; invalidTypes: string[] }> {
    const types = await this.getAllDreamTypes();
    const invalidTypes = types.filter(t => t !== 'Good' && t !== 'Bad');
    return {
      valid: invalidTypes.length === 0,
      invalidTypes,
    };
  }

  /**
   * Check that every row has all 3 columns filled (non-empty)
   */
  async validateAllRowsHaveAllColumns(): Promise<{ valid: boolean; emptyRows: number[] }> {
    const entries = await this.getAllDreamEntries();
    const emptyRows: number[] = [];

    entries.forEach((entry, index) => {
      if (!entry.name || !entry.daysAgo || !entry.dreamType) {
        emptyRows.push(index + 1);
      }
    });

    return {
      valid: emptyRows.length === 0,
      emptyRows,
    };
  }

  /**
   * Count occurrences of each dream name to identify recurring dreams
   */
  async getRecurringDreams(): Promise<Map<string, number>> {
    const entries = await this.getAllDreamEntries();
    const counts = new Map<string, number>();

    for (const entry of entries) {
      const name = entry.name.toLowerCase().trim();
      counts.set(name, (counts.get(name) || 0) + 1);
    }

    // Return only those appearing more than once
    const recurring = new Map<string, number>();
    for (const [name, count] of counts.entries()) {
      if (count > 1) {
        recurring.set(name, count);
      }
    }

    return recurring;
  }

  /**
   * Count good vs bad dreams
   */
  async getDreamTypeCounts(): Promise<{ good: number; bad: number }> {
    const types = await this.getAllDreamTypes();
    return {
      good: types.filter(t => t === 'Good').length,
      bad: types.filter(t => t === 'Bad').length,
    };
  }
}
