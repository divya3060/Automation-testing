# 🌙 Dream Portal – Automated Test Suite

> **Wingify QA Intern Assignment** — Playwright (TypeScript) automation for [Dream Portal](https://arjitnigam.github.io/myDreams/)

---

## 📁 Project Structure

```
dream-portal-tests/
├── pages/                        # Page Object Models (POM)
│   ├── HomePage.ts               # index.html — Dream Portal Home
│   ├── DreamsDiaryPage.ts        # dreams-diary.html — Dream Log Table
│   └── DreamsTotalPage.ts        # dreams-total.html — Summary Stats
│
├── tests/                        # Test Suites
│   ├── homePage.spec.ts          # TC-01 to TC-04: Home page tests
│   ├── dreamsDiary.spec.ts       # TC-05 to TC-10: Diary table tests
│   ├── dreamsTotal.spec.ts       # TC-11 to TC-15: Summary page tests
│   └── aiClassification.spec.ts  # TC-16 to TC-18: 🤖 BONUS AI tests
│
├── utils/
│   ├── aiHelper.ts               # Claude AI dream classifier (Anthropic API)
│   └── logger.ts                 # Structured console + file logger
│
├── playwright.config.ts          # Playwright configuration
├── tsconfig.json                 # TypeScript configuration
└── package.json
```

---

## ✅ Test Coverage

### Part 1: Core UI Functional Tests

| ID     | Page               | Test Description                                               |
|--------|--------------------|----------------------------------------------------------------|
| TC-01  | index.html         | Loading animation appears on page load                        |
| TC-02  | index.html         | Loading animation disappears after ~3 seconds                 |
| TC-03  | index.html         | Main content and "My Dreams" button visible after loading     |
| TC-04  | index.html         | "My Dreams" opens dreams-diary.html & dreams-total.html       |
| TC-05  | dreams-diary.html  | Exactly 10 dream entries in the table                         |
| TC-06  | dreams-diary.html  | Dream types are only "Good" or "Bad"                          |
| TC-07  | dreams-diary.html  | All rows have all 3 columns filled                            |
| TC-08  | dreams-diary.html  | Table has correct headers                                     |
| TC-09  | dreams-diary.html  | Correct counts: 6 Good, 4 Bad                                 |
| TC-10  | dreams-diary.html  | "Flying over mountains" and "Lost in maze" are recurring      |
| TC-11  | dreams-total.html  | Good Dreams stat = 6                                          |
| TC-12  | dreams-total.html  | Bad Dreams stat = 4                                           |
| TC-13  | dreams-total.html  | Total Dreams stat = 10                                        |
| TC-14  | dreams-total.html  | Recurring Dreams stat = 2                                     |
| TC-15  | Both               | Cross-page data consistency check                             |

### Part 2: Bonus AI-Based Tests

| ID     | Test Description                                                        |
|--------|-------------------------------------------------------------------------|
| TC-16  | AI classifies all dream names; ≥70% match diary table values            |
| TC-17  | AI classifies "Monster chase" → **Bad**                                |
| TC-18  | AI classifies "Flying over mountains" → **Good**                       |

---

## 🚀 Setup & Installation

### Prerequisites
- Node.js ≥ 18.x
- npm ≥ 9.x

### Install

```bash
npm install
npx playwright install chromium
```

---

## ▶️ Running Tests

```bash
# Run all tests (headless)
npm test

# Run with visible browser
npm run test:headed

# Run only core tests (no AI)
npx playwright test tests/homePage.spec.ts tests/dreamsDiary.spec.ts tests/dreamsTotal.spec.ts

# Run bonus AI tests
npx playwright test tests/aiClassification.spec.ts

# Run a specific test file
npx playwright test tests/dreamsDiary.spec.ts
```

---

## 📊 Reports

### HTML Report (built-in)
```bash
npm run test:report
# Opens: playwright-report/index.html
```

### Allure Report
```bash
# Generate
npm run allure:generate

# Open in browser
npm run allure:open
```

Screenshots are auto-saved to `test-results/` for every test.

---

## 🤖 AI Integration Details

The bonus AI tests use **Claude (claude-sonnet-4-20250514)** via the Anthropic API to:

1. Receive a dream name as input
2. Classify it as `"Good"` or `"Bad"` based on emotional/experiential tone
3. Compare the AI classification against the actual value in the dreams-diary table
4. Assert ≥70% accuracy across all dreams

**Example:**
```
Input:  "Monster chase"
AI Output: { classification: "Bad", confidence: "High", reasoning: "Monster chases are frightening experiences" }
Table:  "Bad"
Result: ✅ MATCH
```

If the Anthropic API is unavailable, a keyword-based fallback classifier is used automatically.

---

## 🧠 Design Decisions

### Page Object Model (POM)
Each page has a dedicated class in `pages/` with:
- Reusable locators
- Helper methods (e.g., `getAllDreamEntries()`, `getDreamTypeCounts()`)
- No test assertions inside page objects (separation of concerns)

### Resilient Selectors
Locators use multiple strategies (`id`, `class`, `text`, attribute wildcards) to avoid brittleness against minor HTML changes.

### Logging
Every test logs to both console (with colors/icons) and a timestamped `.log` file in `logs/`. This makes debugging CI failures straightforward.

---

## 📝 Evaluation Criteria Addressed

| Criteria         | Implementation                                              |
|------------------|-------------------------------------------------------------|
| Test Coverage    | 18 test cases across all 3 pages                           |
| POM              | `pages/` directory with 3 page classes                     |
| Reporting        | HTML report + Allure + screenshots per test                 |
| AI Integration   | Claude API in `utils/aiHelper.ts` + 3 AI test cases        |
| Clean Commits    | Atomic commits per feature/page                            |
| Bonus Features   | AI classification, cross-page consistency, fallback logic  |

---

## 👤 Author

Automated test suite built for the Wingify QA Intern assignment.
