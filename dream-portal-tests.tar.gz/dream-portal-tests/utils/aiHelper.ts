/**
 * AI Helper - Uses Anthropic Claude API to classify dream names as Good or Bad
 * 
 * This utility demonstrates AI-based validation as bonus functionality.
 * Uses the Claude API (no API key needed in this context via the artifact proxy).
 */

export interface AIClassificationResult {
  dreamName: string;
  aiClassification: 'Good' | 'Bad';
  confidence: string;
  reasoning: string;
}

/**
 * Classify a dream name as "Good" or "Bad" using Claude AI
 */
export async function classifyDreamWithAI(dreamName: string): Promise<AIClassificationResult> {
  const prompt = `You are a dream analyst. Classify the following dream name as either "Good" or "Bad" based on whether the dream is likely a pleasant/positive experience or an unpleasant/negative/frightening experience.

Dream name: "${dreamName}"

Respond with ONLY a JSON object in this exact format (no markdown, no extra text):
{"classification": "Good" or "Bad", "confidence": "High/Medium/Low", "reasoning": "one sentence explanation"}`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 200,
        messages: [
          { role: 'user', content: prompt },
        ],
      }),
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json() as {
      content: Array<{ type: string; text: string }>;
    };

    const rawText = data.content
      .filter((block) => block.type === 'text')
      .map((block) => block.text)
      .join('');

    // Strip any potential markdown code fences
    const cleaned = rawText.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(cleaned) as {
      classification: 'Good' | 'Bad';
      confidence: string;
      reasoning: string;
    };

    return {
      dreamName,
      aiClassification: parsed.classification,
      confidence: parsed.confidence,
      reasoning: parsed.reasoning,
    };
  } catch (error) {
    console.error(`AI classification failed for "${dreamName}":`, error);
    // Fallback: basic keyword-based classification
    return fallbackClassification(dreamName);
  }
}

/**
 * Fallback rule-based classifier (used if API is unavailable)
 */
function fallbackClassification(dreamName: string): AIClassificationResult {
  const badKeywords = [
    'monster', 'chase', 'lost', 'maze', 'nightmare', 'fall', 'falling',
    'dark', 'death', 'scary', 'fear', 'danger', 'attack', 'trapped',
    'flood', 'fire', 'crash', 'fail', 'ghost', 'demon',
  ];
  const goodKeywords = [
    'fly', 'flying', 'rainbow', 'paradise', 'ocean', 'mountain', 'sunshine',
    'friends', 'family', 'love', 'success', 'dream', 'beautiful', 'happy',
    'dance', 'swim', 'adventure', 'journey', 'light', 'peace',
  ];

  const nameLower = dreamName.toLowerCase();

  const isBad = badKeywords.some((kw) => nameLower.includes(kw));
  const isGood = goodKeywords.some((kw) => nameLower.includes(kw));

  let classification: 'Good' | 'Bad';
  if (isBad && !isGood) {
    classification = 'Bad';
  } else if (isGood && !isBad) {
    classification = 'Good';
  } else {
    // Default uncertain dreams to Good
    classification = 'Good';
  }

  return {
    dreamName,
    aiClassification: classification,
    confidence: 'Low',
    reasoning: 'Fallback keyword-based classification (API unavailable)',
  };
}

/**
 * Classify multiple dreams and return results with match analysis
 */
export async function classifyDreamsAndCompare(
  dreams: Array<{ name: string; tableType: string }>
): Promise<Array<AIClassificationResult & { tableType: string; matches: boolean }>> {
  const results = [];

  for (const dream of dreams) {
    console.log(`  🤖 Classifying: "${dream.name}"...`);
    const result = await classifyDreamWithAI(dream.name);

    results.push({
      ...result,
      tableType: dream.tableType,
      matches: result.aiClassification === dream.tableType,
    });

    // Small delay to avoid rate limiting
    await new Promise((resolve) => setTimeout(resolve, 500));
  }

  return results;
}
