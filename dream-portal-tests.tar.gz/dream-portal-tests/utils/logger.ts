import * as fs from 'fs';
import * as path from 'path';

type LogLevel = 'INFO' | 'WARN' | 'ERROR' | 'PASS' | 'FAIL' | 'DEBUG';

const COLORS: Record<LogLevel, string> = {
  INFO:  '\x1b[36m',  // Cyan
  WARN:  '\x1b[33m',  // Yellow
  ERROR: '\x1b[31m',  // Red
  PASS:  '\x1b[32m',  // Green
  FAIL:  '\x1b[31m',  // Red
  DEBUG: '\x1b[90m',  // Gray
};
const RESET = '\x1b[0m';

const ICONS: Record<LogLevel, string> = {
  INFO:  'ℹ️ ',
  WARN:  '⚠️ ',
  ERROR: '❌',
  PASS:  '✅',
  FAIL:  '❌',
  DEBUG: '🔍',
};

class Logger {
  private logLines: string[] = [];
  private logFilePath: string;

  constructor() {
    const logsDir = path.join(process.cwd(), 'logs');
    if (!fs.existsSync(logsDir)) {
      fs.mkdirSync(logsDir, { recursive: true });
    }
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    this.logFilePath = path.join(logsDir, `test-run-${timestamp}.log`);
  }

  private write(level: LogLevel, message: string): void {
    const timestamp = new Date().toISOString();
    const consoleLine = `${COLORS[level]}${ICONS[level]}  [${level}] ${message}${RESET}`;
    const fileLine = `[${timestamp}] [${level}] ${message}`;

    console.log(consoleLine);
    this.logLines.push(fileLine);

    try {
      fs.appendFileSync(this.logFilePath, fileLine + '\n');
    } catch {
      // Non-fatal
    }
  }

  info(message: string): void  { this.write('INFO',  message); }
  warn(message: string): void  { this.write('WARN',  message); }
  error(message: string): void { this.write('ERROR', message); }
  pass(message: string): void  { this.write('PASS',  message); }
  fail(message: string): void  { this.write('FAIL',  message); }
  debug(message: string): void { this.write('DEBUG', message); }

  section(title: string): void {
    const divider = '─'.repeat(60);
    const line = `\n${divider}\n  ${title}\n${divider}`;
    console.log(`\x1b[1m\x1b[35m${line}${RESET}`);
    this.logLines.push(line);
    try { fs.appendFileSync(this.logFilePath, line + '\n'); } catch { /* non-fatal */ }
  }
}

export const logger = new Logger();
