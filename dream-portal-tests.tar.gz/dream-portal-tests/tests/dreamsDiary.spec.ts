import { test, expect } from '@playwright/test';
import { DreamsDiaryPage } from '../pages/DreamsDiaryPage';
import { logger } from '../utils/logger';

test.describe('Dream Portal - Dreams Diary Page (dreams-diary.html)', () => {
  let diaryPage: DreamsDiaryPage;

  test.beforeEach(async ({ page }) => {
    diaryPage = new DreamsDiaryPage(page);
    await diaryPage.goto();
  });

  test('TC-05: Exactly 10 dream entries exist in the table', async ({ page }) => {
    logger.section('TC-05: Verify 10 Dream Entries');

    const count = await diaryPage.getDreamCount();
    logger.info(`Dream entries found: ${count}`);

    await page.screenshot({ path: 'test-results/tc05-dream-count.png' });

    expect(count).toBe(10);
    logger.pass(`Exactly 10 dream entries found ✓`);
  });

  test('TC-06: Dream types are only "Good" or "Bad"', async ({ page }) => {
    logger.section('TC-06: Validate Dream Types');

    const { valid, invalidTypes } = await diaryPage.validateDreamTypes();
    const allTypes = await diaryPage.getAllDreamTypes();

    logger.info(`All dream types: ${allTypes.join(', ')}`);

    await page.screenshot({ path: 'test-results/tc06-dream-types.png' });

    if (!valid) {
      logger.fail(`Invalid dream types found: ${invalidTypes.join(', ')}`);
    } else {
      logger.pass('All dream types are either "Good" or "Bad"');
    }

    expect(valid).toBe(true);
    expect(invalidTypes).toHaveLength(0);
  });

  test('TC-07: Each row has all three columns filled (Dream Name, Days Ago, Dream Type)', async ({ page }) => {
    logger.section('TC-07: Validate All Columns Filled');

    const entries = await diaryPage.getAllDreamEntries();
    logger.info(`Checking ${entries.length} rows for completeness...`);

    const { valid, emptyRows } = await diaryPage.validateAllRowsHaveAllColumns();

    entries.forEach((entry, i) => {
      const status = (!entry.name || !entry.daysAgo || !entry.dreamType) ? '❌' : '✅';
      logger.info(`Row ${i + 1}: ${status} Name="${entry.name}" | DaysAgo="${entry.daysAgo}" | Type="${entry.dreamType}"`);
    });

    await page.screenshot({ path: 'test-results/tc07-all-columns.png' });

    if (!valid) {
      logger.fail(`Rows with empty cells: ${emptyRows.join(', ')}`);
    } else {
      logger.pass('All rows have all three columns filled');
    }

    expect(valid).toBe(true);
    expect(emptyRows).toHaveLength(0);
  });

  test('TC-08: Dream table structure has correct headers', async ({ page }) => {
    logger.section('TC-08: Validate Table Headers');

    // Check for header row
    const headers = await page.locator('table thead th, table tr:first-child th, table tr:first-child td').allTextContents();
    const headerText = headers.map(h => h.trim()).join(', ');
    logger.info(`Table headers: ${headerText}`);

    await page.screenshot({ path: 'test-results/tc08-table-headers.png' });

    // Headers should exist (at least 3 columns)
    expect(headers.length).toBeGreaterThanOrEqual(3);
    logger.pass(`Table has ${headers.length} header columns`);
  });

  test('TC-09: Good and Bad dream counts are correct (6 Good, 4 Bad)', async ({ page }) => {
    logger.section('TC-09: Verify Good/Bad Dream Counts in Diary');

    const { good, bad } = await diaryPage.getDreamTypeCounts();
    logger.info(`Good dreams: ${good}, Bad dreams: ${bad}`);

    await page.screenshot({ path: 'test-results/tc09-good-bad-counts.png' });

    expect(good).toBe(6);
    logger.pass(`Good dreams count = 6 ✓`);

    expect(bad).toBe(4);
    logger.pass(`Bad dreams count = 4 ✓`);
  });

  test('TC-10: Recurring dreams are "Flying over mountains" and "Lost in maze"', async ({ page }) => {
    logger.section('TC-10: Verify Recurring Dreams');

    const recurringMap = await diaryPage.getRecurringDreams();
    const recurringNames = Array.from(recurringMap.keys());

    logger.info(`Recurring dreams found: ${recurringNames.join(', ') || 'none'}`);

    await page.screenshot({ path: 'test-results/tc10-recurring-dreams.png' });

    // Check that the expected recurring dreams appear more than once
    const allEntries = await diaryPage.getAllDreamEntries();
    const allNames = allEntries.map(e => e.name.toLowerCase());

    const flyingCount = allNames.filter(n => n.includes('flying over mountains')).length;
    const mazeCount = allNames.filter(n => n.includes('lost in maze')).length;

    logger.info(`"Flying over mountains" appears: ${flyingCount} time(s)`);
    logger.info(`"Lost in maze" appears: ${mazeCount} time(s)`);

    expect(flyingCount).toBeGreaterThanOrEqual(2);
    logger.pass('"Flying over mountains" is a recurring dream (appears 2+ times)');

    expect(mazeCount).toBeGreaterThanOrEqual(2);
    logger.pass('"Lost in maze" is a recurring dream (appears 2+ times)');
  });
});
