import { test, expect, Page } from '@playwright/test';
import { HomePage } from '../pages/HomePage';
import { logger } from '../utils/logger';

test.describe('Dream Portal - Home Page (index.html)', () => {
  let homePage: HomePage;

  test.beforeEach(async ({ page }) => {
    homePage = new HomePage(page);
  });

  test('TC-01: Loading animation appears on page load', async ({ page }) => {
    logger.section('TC-01: Loading Animation Appears');

    // Navigate and immediately check for loading animation
    await page.goto('/');
    await page.waitForLoadState('domcontentloaded');

    logger.info('Checking for loading animation on page load...');

    // The loading overlay should exist in DOM (may or may not be visible depending on timing)
    const loadingElements = page.locator(
      '#loading-screen, .loading-screen, [id*="loading"], [class*="loading"], [class*="spinner"]'
    );
    const loadingCount = await loadingElements.count();

    logger.info(`Found ${loadingCount} loading-related element(s) in DOM`);

    // Take a screenshot right after load
    await page.screenshot({ path: 'test-results/tc01-loading-initial.png' });

    // Verify that loading elements exist in the DOM (meaning the animation is implemented)
    expect(loadingCount).toBeGreaterThan(0);
    logger.pass('Loading animation element found in DOM');
  });

  test('TC-02: Loading animation disappears after ~3 seconds', async ({ page }) => {
    logger.section('TC-02: Loading Animation Disappears');

    await page.goto('/');
    await page.waitForLoadState('domcontentloaded');

    const startTime = Date.now();
    logger.info('Waiting for loading animation to disappear...');

    // Wait for the loading screen to become hidden (allow up to 8 seconds)
    try {
      await page.waitForFunction(
        () => {
          const loaders = document.querySelectorAll(
            '#loading-screen, .loading-screen, [id*="loading"]'
          );
          if (loaders.length === 0) return true;
          for (const el of loaders) {
            const htmlEl = el as HTMLElement;
            const style = window.getComputedStyle(htmlEl);
            if (
              htmlEl.style.display === 'none' ||
              style.display === 'none' ||
              style.visibility === 'hidden' ||
              style.opacity === '0' ||
              htmlEl.classList.contains('hidden') ||
              htmlEl.hidden
            ) {
              return true;
            }
          }
          return false;
        },
        { timeout: 8000 }
      );
    } catch {
      // If the loading screen never appeared or already gone, that's fine too
      logger.warn('Loading screen wait timed out — may have loaded very fast');
    }

    const elapsed = Date.now() - startTime;
    logger.info(`Loading animation handled in ~${elapsed}ms`);

    await page.screenshot({ path: 'test-results/tc02-loading-disappeared.png' });

    // The elapsed time should be within reasonable range (under 8 seconds)
    expect(elapsed).toBeLessThan(8000);
    logger.pass(`Loading animation disappeared within ${elapsed}ms`);
  });

  test('TC-03: Main content and "My Dreams" button visible after loading', async ({ page }) => {
    logger.section('TC-03: Main Content Visible After Loading');

    await page.goto('/');
    await page.waitForLoadState('networkidle');

    // Give the loading animation time to complete
    await page.waitForTimeout(4000);

    await page.screenshot({ path: 'test-results/tc03-main-content.png' });

    logger.info('Checking main content visibility...');

    // Verify portal title is visible
    const titleVisible = await page.locator('h1, h2').filter({ hasText: /Dream Portal/i }).first().isVisible();
    logger.info(`Portal title visible: ${titleVisible}`);
    expect(titleVisible).toBe(true);
    logger.pass('Portal title is visible');

    // Verify "My Dreams" button is visible
    const myDreamsBtn = page.locator('a, button').filter({ hasText: /My Dreams/i }).first();
    const btnVisible = await myDreamsBtn.isVisible();
    logger.info(`"My Dreams" button visible: ${btnVisible}`);
    expect(btnVisible).toBe(true);
    logger.pass('"My Dreams" button is visible');
  });

  test('TC-04: Clicking "My Dreams" opens dreams-diary.html and dreams-total.html in new tabs', async ({ page, context }) => {
    logger.section('TC-04: My Dreams Button Opens New Tabs');

    await page.goto('/');
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(4000);

    const myDreamsBtn = page.locator('a, button').filter({ hasText: /My Dreams/i }).first();
    await myDreamsBtn.waitFor({ state: 'visible' });

    logger.info('Clicking "My Dreams" button...');

    // Listen for new pages
    const newPagePromises: Promise<Page>[] = [
      context.waitForEvent('page'),
    ];

    await myDreamsBtn.click();

    // Wait a bit for both tabs to open
    await page.waitForTimeout(2000);

    const allPages = context.pages();
    logger.info(`Total pages after click: ${allPages.length}`);

    await page.screenshot({ path: 'test-results/tc04-after-my-dreams-click.png' });

    const allUrls = allPages.map(p => p.url());
    logger.info(`Open URLs: ${allUrls.join(', ')}`);

    const hasDiaryPage = allUrls.some(url => url.includes('dreams-diary.html'));
    const hasTotalPage = allUrls.some(url => url.includes('dreams-total.html'));

    logger.info(`dreams-diary.html opened: ${hasDiaryPage}`);
    logger.info(`dreams-total.html opened: ${hasTotalPage}`);

    expect(hasDiaryPage).toBe(true);
    logger.pass('dreams-diary.html opened in new tab');

    expect(hasTotalPage).toBe(true);
    logger.pass('dreams-total.html opened in new tab');
  });
});
