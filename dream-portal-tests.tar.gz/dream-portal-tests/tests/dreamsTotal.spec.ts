import { test, expect } from '@playwright/test';
import { DreamsTotalPage } from '../pages/DreamsTotalPage';
import { DreamsDiaryPage } from '../pages/DreamsDiaryPage';
import { logger } from '../utils/logger';

test.describe('Dream Portal - Dreams Summary Page (dreams-total.html)', () => {
  let totalPage: DreamsTotalPage;

  test.beforeEach(async ({ page }) => {
    totalPage = new DreamsTotalPage(page);
    await totalPage.goto();
  });

  test('TC-11: Good Dreams stat shows 6', async ({ page }) => {
    logger.section('TC-11: Good Dreams Count = 6');

    const pageText = await totalPage.getPageText();
    logger.debug(`Page text snippet: ${pageText.slice(0, 300)}`);

    await page.screenshot({ path: 'test-results/tc11-good-dreams.png' });

    const goodPresent = await totalPage.isStatPresent(6, 'Good');
    logger.info(`"Good Dreams: 6" present on page: ${goodPresent}`);

    expect(goodPresent).toBe(true);
    logger.pass('Good Dreams count is 6 ✓');
  });

  test('TC-12: Bad Dreams stat shows 4', async ({ page }) => {
    logger.section('TC-12: Bad Dreams Count = 4');

    await page.screenshot({ path: 'test-results/tc12-bad-dreams.png' });

    const badPresent = await totalPage.isStatPresent(4, 'Bad');
    logger.info(`"Bad Dreams: 4" present on page: ${badPresent}`);

    expect(badPresent).toBe(true);
    logger.pass('Bad Dreams count is 4 ✓');
  });

  test('TC-13: Total Dreams stat shows 10', async ({ page }) => {
    logger.section('TC-13: Total Dreams Count = 10');

    await page.screenshot({ path: 'test-results/tc13-total-dreams.png' });

    const totalPresent = await totalPage.isStatPresent(10, 'Total');
    logger.info(`"Total Dreams: 10" present on page: ${totalPresent}`);

    expect(totalPresent).toBe(true);
    logger.pass('Total Dreams count is 10 ✓');
  });

  test('TC-14: Recurring Dreams stat shows 2', async ({ page }) => {
    logger.section('TC-14: Recurring Dreams Count = 2');

    await page.screenshot({ path: 'test-results/tc14-recurring-dreams.png' });

    const recurringPresent = await totalPage.isStatPresent(2, 'Recurring');
    logger.info(`"Recurring Dreams: 2" present on page: ${recurringPresent}`);

    expect(recurringPresent).toBe(true);
    logger.pass('Recurring Dreams count is 2 ✓');
  });

  test('TC-15: All summary stats are consistent with diary data', async ({ page, browser }) => {
    logger.section('TC-15: Cross-Page Data Consistency');

    // Open diary in a separate context to compare
    const diaryContext = await browser.newContext();
    const diaryPage2 = await diaryContext.newPage();
    const diaryPage = new DreamsDiaryPage(diaryPage2);

    await diaryPage.goto();
    const { good, bad } = await diaryPage.getDreamTypeCounts();
    const totalFromDiary = await diaryPage.getDreamCount();
    const recurringFromDiary = await diaryPage.getRecurringDreams();

    logger.info(`From Diary → Good: ${good}, Bad: ${bad}, Total: ${totalFromDiary}, Recurring: ${recurringFromDiary.size}`);

    await diaryContext.close();

    // Now check summary page
    const pageText = await totalPage.getPageText();

    await page.screenshot({ path: 'test-results/tc15-cross-page-consistency.png' });

    // Verify summary page has correct numbers from diary
    expect(pageText).toMatch(new RegExp(`${good}`));
    expect(pageText).toMatch(new RegExp(`${bad}`));
    expect(pageText).toMatch(new RegExp(`${totalFromDiary}`));

    logger.pass(`Summary page stats match diary: Good=${good}, Bad=${bad}, Total=${totalFromDiary}`);
  });
});
