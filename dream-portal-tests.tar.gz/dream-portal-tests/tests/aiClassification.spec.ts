import { test, expect } from '@playwright/test';
import { DreamsDiaryPage } from '../pages/DreamsDiaryPage';
import { classifyDreamsAndCompare } from '../utils/aiHelper';
import { logger } from '../utils/logger';

/**
 * BONUS: AI-Based Dream Classification Validation
 *
 * Uses Claude AI (via Anthropic API) to classify dream names as Good/Bad
 * and compares against the values in the Dream Diary table.
 */
test.describe('BONUS: AI-Based Dream Classification Validation', () => {
  test('TC-16: AI classifies dream names and results match the diary table', async ({ page }) => {
    logger.section('TC-16: AI Dream Classification vs. Table Data');

    const diaryPage = new DreamsDiaryPage(page);
    await diaryPage.goto();

    const entries = await diaryPage.getAllDreamEntries();
    logger.info(`Retrieved ${entries.length} dreams from diary table`);

    const dreamsForClassification = entries.map((e) => ({
      name: e.name,
      tableType: e.dreamType,
    }));

    logger.info('Sending dream names to Claude AI for classification...');
    const results = await classifyDreamsAndCompare(dreamsForClassification);

    // Log full results table
    logger.section('AI Classification Results');
    let matchCount = 0;
    let mismatchCount = 0;

    for (const r of results) {
      const icon = r.matches ? '✅' : '⚠️ ';
      const status = r.matches ? 'MATCH' : 'MISMATCH';
      logger.info(
        `${icon} "${r.dreamName}" → AI: ${r.aiClassification} | Table: ${r.tableType} | ${status} (${r.confidence} confidence)`
      );
      logger.debug(`   Reasoning: ${r.reasoning}`);

      if (r.matches) matchCount++;
      else mismatchCount++;
    }

    const matchRate = ((matchCount / results.length) * 100).toFixed(1);
    logger.section(`Summary: ${matchCount}/${results.length} matches (${matchRate}% accuracy)`);

    await page.screenshot({ path: 'test-results/tc16-ai-classification.png' });

    // The AI should classify at least 70% of dreams correctly
    // (allowing for subjectivity in borderline cases)
    expect(matchCount).toBeGreaterThanOrEqual(Math.floor(results.length * 0.7));

    logger.pass(`AI achieved ${matchRate}% classification accuracy`);
  });

  test('TC-17: AI specifically classifies "Monster chase" as Bad', async () => {
    logger.section('TC-17: AI Spot-Check - Monster Chase → Bad');

    const results = await classifyDreamsAndCompare([
      { name: 'Monster chase', tableType: 'Bad' },
    ]);

    const result = results[0];
    logger.info(`"Monster chase" → AI: ${result.aiClassification} | Expected: Bad`);
    logger.debug(`Reasoning: ${result.reasoning}`);

    expect(result.aiClassification).toBe('Bad');
    logger.pass('"Monster chase" correctly classified as Bad by AI');
  });

  test('TC-18: AI specifically classifies "Flying over mountains" as Good', async () => {
    logger.section('TC-18: AI Spot-Check - Flying over mountains → Good');

    const results = await classifyDreamsAndCompare([
      { name: 'Flying over mountains', tableType: 'Good' },
    ]);

    const result = results[0];
    logger.info(`"Flying over mountains" → AI: ${result.aiClassification} | Expected: Good`);
    logger.debug(`Reasoning: ${result.reasoning}`);

    expect(result.aiClassification).toBe('Good');
    logger.pass('"Flying over mountains" correctly classified as Good by AI');
  });
});
